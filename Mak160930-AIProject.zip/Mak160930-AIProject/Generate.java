
import java.util.*;


public class Generate {
	
	
	
	public static ArrayList<PositionList> generateAdd(PositionList board){
		ArrayList<PositionList> a = new ArrayList();
		
		for(int i=0; i<board.size(); i++){
			if(board.get(i)==positionType.X){
				PositionList c = board.getCopy();
				c.set(i, positionType.W);
				
				if(isCloseMill(i,c)){
					a=generateRemove(c,a);
				}
				else{
					a.add(c);
				}
				
			}
		}
		
		
		return a;
	}

	private static ArrayList<PositionList> generateRemove(PositionList board, ArrayList<PositionList> a) {
		for (int i = 0; i < board.size(); i++){
			if (board.get(i) == positionType.B){
				if (!isCloseMill(i, board)){
					PositionList b = board.getCopy();
					b.set(i, positionType.X);
					a.add(b);
				}
			}
		}
		return a;
	}

	private static boolean isCloseMill(int i, PositionList c) {
		// TODO Auto-generated method stub
		positionType a = c.get(i);
		if(a==positionType.X){
			return false;
		}else{
			return checkMillList(c, i, a);
		}
	}

	private static boolean checkMillList(PositionList c, int i, positionType a) {
		switch(i){
		case 0:
			return (checkMill(c, a, 2, 4) || checkMill(c, a, 6, 18));
		case 1:
			return (checkMill(c, a, 3, 5)||checkMill(c, a,11,20));
		case 2:
			return (checkMill(c, a, 0, 4) || checkMill(c, a, 7, 15));
		case 3:
			return (checkMill(c, a, 1, 5) || checkMill(c, a, 10, 17));
		case 4:
			return (checkMill(c, a, 0, 2)||checkMill(c, a, 8,12) );
		case 5:
			return (checkMill(c, a, 1, 3) || checkMill(c, a, 9, 14));
		case 6:
			return (checkMill(c, a, 0, 18) || checkMill(c, a, 7, 8));
		case 7:
			return (checkMill(c, a, 2, 15) || checkMill(c, a, 6, 8));
		case 8:
			return (checkMill(c, a, 4, 12) || checkMill(c, a, 6, 7));
		case 9:
			return (checkMill(c, a, 5, 14) || checkMill(c, a, 10, 11));
		case 10:
			return (checkMill(c, a, 3, 17) || checkMill(c, a, 9, 11));
		case 11:
			return (checkMill(c, a, 1, 20) || checkMill(c, a, 9, 10));
		case 12:
			return (checkMill(c, a, 4, 8) || checkMill(c, a, 13, 14) || checkMill(c,a,15,18));
		case 13:
			return (checkMill(c, a, 12, 14) || checkMill(c, a, 16, 19));
		case 14:
			return (checkMill(c, a, 5, 9) || checkMill(c, a, 12, 13) || checkMill(c, a, 17, 20));
		case 15:
			return (checkMill(c, a, 2,7) || checkMill(c, a, 12, 18) || checkMill(c, a, 16, 17));
		case 16:
			return (checkMill(c, a, 13, 19) || checkMill(c, a, 15, 17));
		case 17:
			return (checkMill(c, a, 3, 10) || checkMill(c, a, 14, 20) || checkMill(c, a, 15, 16));
		case 18:
			return (checkMill(c, a, 0, 6) || checkMill(c, a, 12, 15)||checkMill(c, a, 19, 20));
		case 19:
			return (checkMill(c, a, 13, 16) || checkMill(c, a, 18, 20));
		case 20:
			return (checkMill(c, a, 1,11) || checkMill(c, a, 14, 17) || checkMill(c, a, 18, 19));
		default:
			return false;
		}
	}
	
	private static boolean checkMill(PositionList a, positionType c, int v1, int v2){
		return (a.get(v1) == c && a.get(v2) == c);
	}
	
	public static ArrayList<PositionList> generateHopping(PositionList board){
		ArrayList<PositionList> a = new ArrayList<PositionList>();
		for (int i = 0; i < board.size(); i++){
			if (board.get(i) == positionType.W){
				for (int j = 0; j < board.size(); j++){
					if (board.get(j) == positionType.X){
						PositionList b = board.getCopy();
						b.set(i, positionType.X);
						b.set(j, positionType.W);
						if (isCloseMill(j, b))
							generateRemove(b, a);
						else
							a.add(b);
					}
				}
			}
		}
		return a;
	}
	
	
	public static ArrayList<PositionList> generateMove(PositionList board){
		ArrayList<PositionList> a = new ArrayList<PositionList>();
		for (int i = 0; i < board.size(); i++){
			if (board.get(i) == positionType.W){
				List<Integer> n = getNeighbors(i);
				for (int j : n){
					if (board.get(j) == positionType.X){
						PositionList b = board.getCopy();
						b.set(i, positionType.X);
						b.set(j, positionType.W);
						if (isCloseMill(j, b)){
							a = generateRemove(b, a);
						}
						else{
							a.add(b);
						}
					}
				}
			}
		}
		return a;
	}
	
	
	public static ArrayList<Integer> getNeighbors(int i){
		switch(i){
			case 0:
				return new ArrayList<Integer>(Arrays.asList(1, 2, 6));
			case 1:
				return new ArrayList<Integer>(Arrays.asList(0, 3, 11));
			case 2:
				return new ArrayList<Integer>(Arrays.asList(0, 3, 4 ,7));
			case 3:
				return new ArrayList<Integer>(Arrays.asList(1,2,5,10));
			case 4:
				return new ArrayList<Integer>(Arrays.asList(2,5,8));
			case 5:
				return new ArrayList<Integer>(Arrays.asList(3, 4, 9));
			case 6:
				return new ArrayList<Integer>(Arrays.asList(0, 7, 18));
			case 7:
				return new ArrayList<Integer>(Arrays.asList(2, 6, 8,15));
			case 8:
				return new ArrayList<Integer>(Arrays.asList(4, 7, 12));
			case 9:
				return new ArrayList<Integer>(Arrays.asList(5,10,14));
			case 10:
				return new ArrayList<Integer>(Arrays.asList(3,9,11,17));
			case 11:
				return new ArrayList<Integer>(Arrays.asList(1,10,20));
			case 12:
				return new ArrayList<Integer>(Arrays.asList(8, 13, 15));
			case 13:
				return new ArrayList<Integer>(Arrays.asList(12, 14,16));
			case 14:
				return new ArrayList<Integer>(Arrays.asList(9, 13, 17));
			case 15:
				return new ArrayList<Integer>(Arrays.asList(7,12,16,18));
			case 16:
				return new ArrayList<Integer>(Arrays.asList(13, 15, 17,19));
			case 17:
				return new ArrayList<Integer>(Arrays.asList(10, 14, 16, 20));
			case 18:
				return new ArrayList<Integer>(Arrays.asList(6, 15,19));
			case 19:
				return new ArrayList<Integer>(Arrays.asList(16,18,20));
			case 20:
				return new ArrayList<Integer>(Arrays.asList(11,17,19));
			default:
				return (new ArrayList<Integer>());
		}
	}
	
	public static int staticEstimationOpening(PositionList board){
		return board.getPieceCount(positionType.W)-board.getPieceCount(positionType.B);
	}
	
	public static ArrayList<PositionList> generateMovesOpening(PositionList board){
		return generateAdd(board);
	}
	
	public static ArrayList<PositionList> generateMovesMidgame(PositionList board){
		if (board.getPieceCount(positionType.W) == 3)
			return generateHopping(board);
		else
			return generateMove(board);
	}
	
	public static int staticEstimationMidGame(PositionList board){
		int whiteCount = board.getPieceCount(positionType.W);
		int blackCount = board.getPieceCount(positionType.B);
		ArrayList<PositionList> l = generateMovesMidgameBlack(board);
		int movesCount = l.size();
		if (blackCount <= 2)
			return 10000;
		else if (whiteCount <= 2)
			return -10000;
		else if (movesCount == 0)
			return 10000;
		else
			return 1000*(whiteCount - blackCount) - movesCount;
	}
	
	public static ArrayList<PositionList> generateMovesOpeningBlack(PositionList board){
		PositionList tempBoard = board.flip();
		ArrayList<PositionList> moves = generateMovesOpening(tempBoard);
		for (int i = 0; i < moves.size(); i++){
			PositionList b = moves.get(i);
			moves.set(i, b.flip());
		}
		return moves;
	}
	
	public static ArrayList<PositionList> generateMovesMidgameBlack(PositionList board){
		PositionList tempboard = board.flip();
		ArrayList<PositionList> moves = generateMovesMidgame(tempboard);
		ArrayList<PositionList> output = new ArrayList<PositionList>();
		for (int i = 0; i < moves.size(); i++){
			PositionList b = moves.get(i);
			output.add(b.flip());
		}
		return output;
	}
	
	//Improvement in Static Estimation: take into account how many potential mills W has 	
	public static int getPotentialMillsCount(positionType pos, PositionList board){
		int counter = 0;
		for (int i = 0; i< board.size(); i++){
			positionType a = board.get(i);
			if (a == positionType.X){
				if (checkMillList(board, i, a))
					counter++;
			}
		}
		return counter;
	}
		
	
	public static int staticEstimationOpeningImproved(PositionList board){
		return (board.getPieceCount(positionType.W) + getPotentialMillsCount(positionType.W, board) - board.getPieceCount(positionType.B));
	}
	
	public static int staticEstimationMidgameImproved(PositionList board){
		int blackCount = board.getPieceCount(positionType.B);
		int whiteCount = board.getPieceCount(positionType.W);
		int potentialMillCount = getPotentialMillsCount(positionType.W, board);
		ArrayList<PositionList> l = generateMovesMidgameBlack(board);
		int movesCount = l.size();
		if (blackCount <= 2){
			return 10000;
		}
		else if (whiteCount <= 2){
			return -10000;
		}
		else if (movesCount == 0){
			return 10000;
		}
		else{
			return 1000*(whiteCount - blackCount + potentialMillCount) - movesCount;
		}
	}
}