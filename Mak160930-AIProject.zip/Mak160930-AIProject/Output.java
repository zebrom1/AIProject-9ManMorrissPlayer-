
public class Output {
	public int value;
	public int nodesCount;
	public PositionList a;
	public String getfinalboard() {
		return a.toString();
	}
	
	public String toString() {
		return "Board position:\t" +a+"\n Positions Evaluated: \n"+ nodesCount+ "\n Position evaluation:" +value; 
	}

}
