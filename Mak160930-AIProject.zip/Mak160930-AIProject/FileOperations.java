import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.io.File;
import java.util.Scanner;


public class FileOperations {
	public static ArrayList<Character> getBoard(String fileName) throws IOException{
		String line = null;
		File readfile= new File(fileName);
		if(readfile.exists()) {
			System.out.println("the file is here");
		}
		Scanner fileReader= new Scanner(readfile);
		line = fileReader.nextLine();
		ArrayList<Character> output = new ArrayList<Character>();
		for (char a : line.toCharArray())
			output.add(a);
		System.out.println(output);
		fileReader.close();
		return output;
	}
	
	public static void writeOutput(Output output, String fileName) throws IOException{
		FileWriter fileWriter = new FileWriter(fileName);
		BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
		fileWriter.write(output.getfinalboard());
		bufferedWriter.close();
		fileWriter.close();
	}
}