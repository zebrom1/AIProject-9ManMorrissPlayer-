public enum positionType {
	
	X ('x'),
	B ('B'),
	W ('W');
	
	public final char value;
	positionType(char value){
		this.value = value;
	}
}