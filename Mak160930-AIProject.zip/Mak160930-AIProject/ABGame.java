import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
public class ABGame {
	public static void main(String[] args) throws IOException{
		String inputFile = args[0];
		String outputFileName = args[1];
		int depth = Integer.parseInt(args[2]);

		PositionList startboard = new PositionList(FileOperations.getBoard(inputFile));
		Output output = ABMiniMax(depth, true, startboard, -99999999,99999999);
		System.out.println(output.toString());
		FileOperations.writeOutput(output, outputFileName);
	}
	
	public static Output ABMiniMax(int depth, boolean isWhite, PositionList board, int alpha, int beta){
		Output output = new Output();

		if (depth == 0){
			output.value = Generate.staticEstimationMidGame(board);
			output.nodesCount++;
			return output;
		}

		ArrayList<PositionList> nextMoves;
		Output in = new Output();
		nextMoves = (isWhite) ? Generate.generateMovesMidgame(board) : Generate.generateMovesMidgameBlack(board);
		for (PositionList b : nextMoves){
			if (isWhite){
				in = ABMiniMax(depth - 1, false, b, alpha, beta);
				output.nodesCount += in.nodesCount;
				output.nodesCount++;
				if (in.value > alpha)
				{
					alpha = in.value;
					output.a = b;
				}
			}
			else{
				in = ABMiniMax(depth - 1, true, b, alpha, beta);
				output.nodesCount += in.nodesCount;
				if (in.value < beta)
				{
					beta = in.value;
					output.a = b;
				}
			}
			if (alpha >= beta){
				break;
			}
		}
		
		output.value = (isWhite) ? alpha : beta;
		return output;
	}
}
